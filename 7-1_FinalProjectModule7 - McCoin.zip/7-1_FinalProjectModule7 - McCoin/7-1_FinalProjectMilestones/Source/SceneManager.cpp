///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/
	bool bReturn = false;

	bReturn = CreateGLTexture(
		"textures/wood.jpg",
		"wood");

	bReturn = CreateGLTexture(
		"textures/flower.jpg",
		"flower");

	bReturn = CreateGLTexture(
		"textures/side.jpg",
		"side");


	bReturn = CreateGLTexture(
		"textures/screen.jpg",
		"screen");

	bReturn = CreateGLTexture(
		"textures/fan.jpg",
		"fan");

	bReturn = CreateGLTexture(
		"textures/keyboard.jpg",
		"keyboard");

	bReturn = CreateGLTexture(
		"textures/key.jpg",
		"key");



	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	/*** STUDENTS - add the code BELOW for defining object materials. ***/
	/*** There is no limit to the number of object materials that can ***/
	/*** be defined. Refer to the code in the OpenGL Sample for help  ***/

	OBJECT_MATERIAL goldMaterial;
	goldMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	goldMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	goldMaterial.shininess = 25.0;
	goldMaterial.tag = "metal";

	m_objectMaterials.push_back(goldMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	woodMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	woodMaterial.shininess = 55.0;
	woodMaterial.tag = "desk";

	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL floorMaterial;
	floorMaterial.diffuseColor = glm::vec3(0.24f, 0.6f, 0.64f);
	floorMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	floorMaterial.shininess = 3.0;
	floorMaterial.tag = "flat";

	m_objectMaterials.push_back(floorMaterial);

	OBJECT_MATERIAL flowerMaterial;
	flowerMaterial.diffuseColor = glm::vec3(0.4, 0.34, 0.28);
	flowerMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	flowerMaterial.shininess = 0.1;
	flowerMaterial.tag = "flower";

	m_objectMaterials.push_back(flowerMaterial);

	OBJECT_MATERIAL flowerPetalMaterial;
	flowerPetalMaterial.diffuseColor = glm::vec3(0.11, 0.16, 0.11);
	flowerPetalMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	flowerPetalMaterial.shininess = 0.001;
	flowerPetalMaterial.tag = "flowerPetal";

	m_objectMaterials.push_back(flowerPetalMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.0f, 0.22f, 0.21f);
	glassMaterial.specularColor = glm::vec3(0.0f, 0.64f, 0.61f);
	glassMaterial.shininess = 1.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.diffuseColor = glm::vec3(0.0f, 0.22f, 0.21f);
	plasticMaterial.specularColor = glm::vec3(0.0f, 0.64f, 0.61f);
	plasticMaterial.shininess = 15.0;
	plasticMaterial.tag = "glass";

	m_objectMaterials.push_back(plasticMaterial);

}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	//m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help      ***/
	
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// point light 1 (index 0)
	m_pShaderManager->setVec3Value("pointLights[0].position", -4.95f, 8.07f, -8.27f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.9f, 0.9f, 0.9f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// point light 2 (index 1)
	// Monitor
	m_pShaderManager->setVec3Value("pointLights[1].position", -1.2f, 7.30f, -8.95f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.0f, 0.09f, 0.09f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.0f, 0.09f, 0.09f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.44f, 0.44f, 0.44f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// directional light 3 
	// Monitor
	m_pShaderManager->setVec3Value("directionalLight.direction", -1.65f, 5.25f, -8.0f);
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();

	// define the materials for objects in the scene
	DefineObjectMaterials();
	// add and define the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();


}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Floor (Plane)	***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 5.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, -5.0f);		// X value set to 0, Y value to 0, and Y value to -5 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("flat");
	SetShaderColor(0.21, 0.22, 0.23, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

	/*** Ceiling (Plane)	***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 5.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 20.0f, -5.0f);		// X value set to 0, Y value to 20 to move up, and Y value to -5 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.21, 0.22, 0.23, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

	/*** Back Wall (Plane)	***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;		// Rotate 90 degrees on X axis
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 10.0f, -10.0f);		// X value set to 0, Y value to 10 to move up, and Y value to -10 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	SetShaderColor(0.03, 0.37, 0.43, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

	/*** Left Wall (Plane)	***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;		// Rotate 90 degrees on X axis
	YrotationDegrees = 90.0f;		// Rotate 90 degrees on Y axis
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-20.0f, 10.0f, -5.0f);		// X value set to -20, Y value to 10 to move up, and Y value to -5 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	SetShaderColor(0.03, 0.37, 0.43, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/


	/*** Right Wall (Plane)	***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;		// Rotate 90 degrees on X axis
	YrotationDegrees = 90.0f;		// Rotate 90 degrees on Y axis
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(20.0f, 10.0f, -5.0f);		// X value set to 20, Y value to 10 to move up, and Y value to -5 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	SetShaderColor(0.03, 0.37, 0.43, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

	
	/*** Desk ***/
	/*** Deks Drawers (Box) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.25f, 5.0f, 3.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;	
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.0f, 2.5f, -8.0f);		// X value set to -6, Y value to 2.5 to move up, and Y value to -8 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderTexture("wood");
	SetTextureUVScale(0.75, 0.75);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::back);
	SetShaderTexture("wood");
	SetTextureUVScale(0.75, 0.75);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::bottom);
	SetShaderTexture("wood");
	SetTextureUVScale(0.75, 0.75);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::left);
	SetShaderTexture("wood");
	SetTextureUVScale(0.75, 0.75);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::right);
	SetShaderTexture("wood");
	SetTextureUVScale(0.75, 0.75);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::top);
	SetShaderTexture("wood");
	SetTextureUVScale(0.75, 0.75);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::front);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	/*** Desk Drawer Top (Plane)	***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.0f, 3.75f, -6.37f);		// X value set to 0, Y value to 20 to move up, and Y value to -5 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.11, 0.11, 0.11, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

	/*** Desk Drawer Bottom (Plane)	***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 1.25f, 1.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.0f, 1.5f, -6.37f);		// X value set to -6.0, Y value to 1.5 to move up, and Y value to -6.37 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.11, 0.11, 0.11, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/

	/*** Desktop (Box) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(12.0f, 0.5f, 3.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;	
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.65f, 5.25f, -8.0f);		// X value set to -1.65, Y value to 5.25 to move up, and Y value to -8 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderMaterial("desk");
	SetShaderColor(0.11, 0.11, 0.11, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::back);
	SetShaderTexture("wood");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::bottom);
	SetShaderColor(0.11, 0.11, 0.11, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::left);
	SetShaderColor(0.11, 0.11, 0.11, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::right);
	SetShaderTexture("wood");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::top);
	SetShaderColor(0.11, 0.11, 0.11, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::front);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/

	/*** Leg 1 (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.10f, 5.25f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 10.0f;	// Rotate the x distance factor to 10 degrees to rotate the desk leg 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.0f, 0.00f, -9.0f);		// X value set to 3 and Y value to -9 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderTexture("wood");
	SetTextureUVScale(1.0, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/*** Leg 2 (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.10f, 5.25f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -10.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(3.0f, 0.0f, -7.0f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderTexture("wood");
	SetTextureUVScale(1.0, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/*** End of Desk ***/


	/*** Plant ***/
	/*** Plant vase (Tapered Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.40f, 1.0f, 0.40f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.75f, 6.50f, -9.0f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// Set color for the ends of te tapered cylinder
	SetShaderMaterial("flower");
	SetShaderColor(0.37, 0.36, 0.35, 1.0);
	m_basicMeshes->DrawTaperedCylinderMesh(true, true, false);

	// Set the color for the cylinder circumference 
	SetShaderMaterial("flower");
	SetShaderColor(0.61, 0.58, 0.56, 1.0);
	m_basicMeshes->DrawTaperedCylinderMesh(false, false, true);


	/****************************************************************/

	/*** Plant stems (Cylinder) ***/
	/*Middle Stem*/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.025f, 0.70f, 0.025f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.75f, 6.50f, -9.25f);		// X value set to -6.75, Y value to 6.5 to move up, and Y value to -9.25 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("flower");
	SetShaderColor(0.04, 0.19, 0.06, 1.0);


	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/*Right Stem*/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.025f, 0.50f, 0.025f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 15.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.60f, 6.50f, -9.0f);		// X value set to -6.60, Y value to 6.5 to move up, and Y value to -9.0 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("flower");
	SetShaderColor(0.04, 0.19, 0.06, 1.0);


	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/*Left Stem*/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.025f, 0.5f, 0.025f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 15.0f;
	YrotationDegrees = 270.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.90f, 6.50f, -8.85f);		// X value set to -6.90, Y value to 6.5 to move up, and Y value to -8.85 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("flower");
	SetShaderColor(0.04, 0.19, 0.06, 1.0);


	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/

	/*** Plant Flower (Cone) ***/
	/*Middle Flower*/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 0.65f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.75f, 7.0f, -9.25f);		// X value set to -6.75, Y value to 7.0 to move up, and Y value to -9.25 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderMaterial("flowerPetal");
	SetShaderTexture("flower");
	SetTextureUVScale(1.0, 1.0);

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();

	/****************************************************************/
	/*Right Flower*/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 0.65f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 25.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.50f, 6.8f, -9.0f);		// X value set to -6.50, Y value to 6.8 to move up, and Y value to -9.0 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderMaterial("flowerPetal");
	SetShaderTexture("flower");
	SetTextureUVScale(1.0, 1.0);


	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();



	/****************************************************************/
	/*Left Flower*/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 0.65f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 15.0f;
	YrotationDegrees = 270.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.97f, 6.70f, -8.87f);		// X value set to -6.97, Y value to 6.70 to move up, and Y value to -8.87 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderMaterial("flowerPetal");
	SetShaderTexture("flower");
	SetTextureUVScale(1.0, 1.0);


	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();



	/****************************************************************/

	/****************************************************************/
	/*** End of Plant ***/


	/*** Lamp ***/
	/*** Lamp Base (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.50f, 0.15f, 0.50f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.75f, 10.0f, -10.0f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderColor(0.11, 0.11, 0.11, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, true, false);

	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawCylinderMesh(false, false, true);
	/****************************************************************/

	/*** Lamp Arm, Top/Back (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 1.75f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -65.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.75f, 9.40f, -8.25f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, true, true);
	/****************************************************************/

	/*** Lamp Arm, Bottom/Back (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 1.75f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -65.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.75f, 9.15f, -8.25f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, true, true);
	/****************************************************************/

	/*** Lamp Arm, Top/Front (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 1.75f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 245.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = -90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.77f, 9.40f, -8.27f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, true, true);
	/****************************************************************/

	/*** Lamp Arm, Bottom/Front (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 1.75f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 245.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = -90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-6.77f, 9.17f, -8.27f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, true, true);
	/****************************************************************/

	/*** Lamp shade/base (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.25f, 0.45f, 0.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 15.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 8.30f, -8.27f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set the color for the cylinder circumference
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, true, true);
	/****************************************************************/

	/*** Lamp shade/base/sphere (Sphere) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 15.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.1015f, 8.689f, -8.27f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/*** Lamp shade (Cone) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.45f, 0.60f, 0.45f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;	// Rotate the x distance factor to -10 degrees to rotate the desk leg 
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 15.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.95f, 8.07f, -8.27f);		// X value set to 3 and Y value to -7 to move the leg back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderMaterial("metal");
	SetShaderColor(0.06, 0.06, 0.06, 1.0);
	m_basicMeshes->DrawConeMesh();
	/****************************************************************/
	/*** End of Lamp ***/


	/*** Desktop ***/
	/*** Desktop (box) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.5f, 3.25f, 2.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.6f, 7.10f, -8.0f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// set the texture for the next draw command
	SetShaderMaterial("metal");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::back);
	SetShaderMaterial("metal");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::bottom);
	SetShaderMaterial("glass");
	SetShaderTexture("side");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::left);
	SetShaderMaterial("metal");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::right);
	SetShaderMaterial("metal");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::top);
	SetShaderMaterial("metal");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::front);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/
	/*** Desktop fan top (cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.48f, 0.025f, 0.48f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.6f, 8.15f, -6.75f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderTexture("fan");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/*** Desktop fan middle (cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.48f, 0.025f, 0.48f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.6f, 7.10f, -6.75f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderTexture("fan");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/*** Desktop fan bottom (cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.48f, 0.025f, 0.48f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(2.6f, 6.05f, -6.75f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// Set the color for the cylinder circumference 
	SetShaderMaterial("metal");
	SetShaderTexture("fan");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/
	/*** End of Desktop ***/


	/*** Monitor ***/
	/*** Monitor (box) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.0f, 2.75f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.2f, 7.30f, -9.0f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// set the texture for the next draw command
	SetShaderMaterial("glass");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::back);
	SetShaderMaterial("glass");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::bottom);
	SetShaderMaterial("glass");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::left);
	SetShaderMaterial("glass");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::right);
	SetShaderMaterial("glass");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::top);
	SetShaderMaterial("glass");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::front);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/*** Monitor screen (plane) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.85f, 2.60f, 0.10f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.2f, 7.30f, -8.99f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// set the texture for the next draw command
	SetShaderMaterial("glass");
	SetShaderTexture("screen");
	SetTextureUVScale(1.0, 1.0);
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/*** Monitor Stand (cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 0.43f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.2f, 5.50f, -9.0f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/*** Monitor Stand Base (cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 0.05f, 0.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.2f, 5.525f, -9.0f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/
	/*** End of Monitor ***/



	/*** Keyboard (Box) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.75f, 0.08f, 0.8f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 15.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.5f, 5.645f, -7.9f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the texture for the next draw command
	SetShaderMaterial("flat");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::back);
	SetShaderMaterial("flat");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::bottom);
	SetShaderMaterial("flat");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::left);
	SetShaderMaterial("flat");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::right);
	SetShaderMaterial("flat");
	SetShaderTexture("key");
	SetTextureUVScale(1.0, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::top);
	SetShaderMaterial("flat");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::front);

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/
	/*** End of Keyboard ***/

	/*Mouse*/
	/*** Mouse (Cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.25f, 0.13f, 0.3f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 5.5f, -7.5f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderMaterial("metal");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/*** Mouse (Sphere) ***/
	/*****************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.25f, 0.142f, 0.3f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 5.63f, -7.5f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderMaterial("metal");
	SetShaderColor(0.00, 0.00, 0.00, 1.0);
	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/

	/*** Mouse wheel (cylinder) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 0.05f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.98f, 5.76f, -7.6f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderMaterial("metal");
	SetShaderColor(0.13, 0.13, 0.13, 1.0);
	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	/*** Mouse Pad (plane) ***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.7f, 0.7f, 0.7f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(1.0f, 5.501f, -7.5f);		// X value set to -6.75, Y value to 6.50 to move up, and Y value to -9 to move back 

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color for the ends of te tapered cylinder
	SetShaderMaterial("flat");
	SetShaderColor(0.01, 0.07, 0.00, 1.0);
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/
}
